

#ifndef __WDF_USB_DD_PUBLIC__
#define __WDF_USB_DD_PUBLIC__

/*WDF USB device GUID*/
// {C6B78DFF-B260-4161-84ED-09CA267F3E15}
DEFINE_GUID(GUID_DEVINTERFACE_FX2, 
0xc6b78dff, 0xb260, 0x4161, 0x84, 0xed, 0x9, 0xca, 0x26, 0x7f, 0x3e, 0x15);

/*device IO control codes for the WDF USB driver*/
#define IOCTL_INDEX             0x800
#define FILE_DEVICE_USB_FX2     0x65500

#define IOCTL_WDF_USB_GET_SWITCHSTATE CTL_CODE(FILE_DEVICE_USB_FX2,     \
                                                     IOCTL_INDEX,       \
                                                     METHOD_BUFFERED,   \
                                                     FILE_READ_ACCESS)

#define IOCTL_WDF_USB_SET_LIGHTBAR    CTL_CODE(FILE_DEVICE_USB_FX2,     \
                                                     IOCTL_INDEX + 1,   \
                                                     METHOD_BUFFERED,   \
                                                     FILE_WRITE_ACCESS)

#define IOCTL_WDF_USB_GET_LIGHTBAR    CTL_CODE(FILE_DEVICE_USB_FX2,     \
                                                     IOCTL_INDEX + 2,   \
                                                     METHOD_BUFFERED,   \
                                                     FILE_READ_ACCESS)

#define IOCTL_WDF_USB_GET_SWITCHSTATE_CHANGE CTL_CODE(FILE_DEVICE_USB_FX2,\
                                                     IOCTL_INDEX + 3,       \
                                                     METHOD_BUFFERED,   \
                                                     FILE_READ_ACCESS)
#endif //__WDF_USB_DD_PUBLIC__